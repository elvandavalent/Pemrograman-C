#include <stdio.h>
#include <string.h>
int main()
{
    char os[6];
    strcpy(os, "Linux");
    printf("Nilai variabel os: %s\n", os);
    return 0;
}