#include <stdio.h>
int main (){
    double a = 112.45677;
    double b = 312332.6677;
    printf("%16.101f\n", a);
    printf("%16.61f\n", a);
    printf("%16.21f\n", a);
    printf("%16.101f\n", b);
    printf("%16.61f\n", b);
    printf("%16.21f\n", a);
    return 0;
}