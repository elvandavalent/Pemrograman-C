#include <stdio.h>
#include <math.h>

int main()
{
    printf("sqrt(25):%0.lf\n", sqrt(25));
    printf("sqrt(100):%0.lf\n", sqrt(100));
    printf("sqrt(5):%lf\n", sqrt(5));
    printf("sqrt(12):%lf\n", sqrt(12));
}