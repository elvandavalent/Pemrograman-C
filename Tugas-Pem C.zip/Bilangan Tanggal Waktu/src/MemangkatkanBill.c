#include <stdio.h>
#include <math.h>

int main()
{
    printf("pow(2,5):%0.lf\n", pow(2, 5));
    printf("pow(2,64):%0.lf\n", pow(2, 64));
    printf("pow(3.0,3):%lf\n", pow(3.0, 3));
    printf("pow(5.2,2):%lf\n", pow(5.2, 2));
    return 0;
}